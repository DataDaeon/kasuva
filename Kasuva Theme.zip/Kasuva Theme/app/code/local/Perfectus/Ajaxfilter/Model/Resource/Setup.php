<?php
	
class daeon_Ajaxfilter_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup {
	
}