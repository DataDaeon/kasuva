<?php
class daeon_kasuva_Model_Resource_Mysql4_Setup extends Mage_Core_Model_Resource_Setup
{
    public function _construct()
    {    
        
    }
}